
const commentetor = require('./commentetor');
function demo(){
    console.log("hello world");
}

demo();



commentetor('./demo/').then((data)=>{
    console.log("then ==",data)
}).catch((error)=>{
    console.log("catch === ",error);
});;