const fs = require('fs').promises;


 const commentetor = (path) => {
    return new Promise(async (resolve, reject) => {
        try {
            const file = await fs.readdir(path);
            for (let i = 0; i < file.length; ++i) {
                ;
                const checker = await fs.lstat(path + file[i]);
                if (checker.isFile()) {
                  const data =  await fs.readFile(path + file[i],"utf8");
                  console.log("data ::",data);
                  const  arr1 = data.split("function");
                  let arr2 =  arr1[0];
                  for (let j = 1; j < arr1.length; ++j) {
                    arr2 +="/** \r\n * Write description here \r\n * Function XYZ \r\n * Return {*} \r\n*/ \r\nfunction"+arr1[j];           
                  }
                  await fs.writeFile(path + file[i],arr2);
            
                }
                else {
                    // await routeAccess(path + file[i]+'/');
                }
                console.log("sign ===",i, file[i])
            };
            resolve(true);
        } catch (error) {
            reject(error);
        }
    });
}

module.exports = commentetor;