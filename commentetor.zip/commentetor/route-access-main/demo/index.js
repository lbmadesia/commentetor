
/** 
 * Write description here 
 * Function XYZ 
 * Return {*} 
*/ 
function hellolb(){
    console.log("hello lb");
}
 
/** 
 * Write description here 
 * Function XYZ 
 * Return {*} 
*/ 
function demo2(){
    console.log("hello demo2");
}